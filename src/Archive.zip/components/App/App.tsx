import RouteClientTestPage from '../../pages/RouteClientTestPage/RouteClientTestPage.tsx';
import { SearchPage } from '../../pages/SearchPage/SearchPage.tsx';

export default function App() {
  return (
    <RouteClientTestPage/>
  );
}

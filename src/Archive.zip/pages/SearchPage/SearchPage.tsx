import React, { useState } from 'react';
import { AirportAutocomplete } from '../../components/AirportAutocomplete/AirportAutocomplete';
import { AirportOption } from '../../types/airport';
import styles from './SearchPage.module.scss';
import { FlightRoute } from '../../types/route';
import { RouteCard } from '../../components/RouteCard/RouteCard';

const sampleRoute: FlightRoute = {
  id: 'route-sample-long-layover',
  totalPrice: 64200,
  totalDuration: '3 дня 14ч',
  transfersCount: 2,
  segments: [
    {
      departureCity: 'Екатеринбург',
      departureCode: 'SVX',
      departureTime: '2026-10-18T06:00:00',
      departureTimeFormatted: '18 окт, 06:00',
      arrivalCity: 'Москва',
      arrivalCode: 'SVO',
      arrivalTime: '2026-10-18T06:45:00',
      arrivalTimeFormatted: '18 окт, 06:45',
      duration: '2ч 45м',
    },
    {
      departureCity: 'Москва',
      departureCode: 'DME', // Смена аэропорта в Москве
      departureTime: '2026-10-20T10:20:00', // Вылет через 2 суток и 3.5 часа!
      departureTimeFormatted: '20 окт, 10:20',
      arrivalCity: 'Стамбул',
      arrivalCode: 'IST',
      arrivalTime: '2026-10-20T14:10:00',
      arrivalTimeFormatted: '20 окт, 14:10',
      duration: '4ч 50м',
    },
    {
      departureCity: 'Стамбул',
      departureCode: 'IST',
      departureTime: '2026-10-22T09:00:00', // Вылет из Стамбула через 1 сутки
      departureTimeFormatted: '22 окт, 09:00',
      arrivalCity: 'Анталья',
      arrivalCode: 'AYT',
      arrivalTime: '2026-10-22T10:30:00',
      arrivalTimeFormatted: '22 окт, 10:30',
      duration: '1ч 30м',
    },
  ],
};

export const SearchPage: React.FC = () => {
  const [origin, setOrigin] = useState<AirportOption | null>(null);
  const [destination, setDestination] = useState<AirportOption | null>(null);

  const handleSwap = () => {
    const temp = origin;
    setOrigin(destination);
    setDestination(temp);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!origin || !destination) {
      alert('Пожалуйста, выберите город отправления и назначения из списка');
      return;
    }
    console.log('Поиск рейса:', { from: origin.code, to: destination.code });
  };

  return (
    <main className={styles.searchPage}>
      <div className={styles.container}>
        <h1 className={styles.title}>Поиск авиабилетов</h1>
        
        <form className={styles.searchForm} onSubmit={handleSearch}>
          <div className={styles.fieldsRow}>
            <AirportAutocomplete
              label="Откуда"
              value={origin ? `${origin.cityName} (${origin.code})` : ''}
              onChange={setOrigin}
              placeholder="Город или код (напр., SVX)"
            />

            <button
              type="button"
              className={styles.swapButton}
              onClick={handleSwap}
              title="Поменять местами"
            >
              ⇄
            </button>

            <AirportAutocomplete
              label="Куда"
              value={destination ? `${destination.cityName} (${destination.code})` : ''}
              onChange={setDestination}
              placeholder="Город или код (напр., IST)"
            />
          </div>

          <button type="submit" className={styles.submitButton}>
            Найти билеты
          </button>
        </form>

        {/* Блок с примером отображения маршрута */}
        <section className={styles.previewSection}>
          <h2 className={styles.previewTitle}>Пример найденного маршрута (с пересадками)</h2>
          <RouteCard 
            route={sampleRoute} 
            onSelect={() => alert('Маршрут выбран!')} 
          />
        </section>
      </div>
    </main>
  );
};
import { api } from './api';

export type QueryStatus =
  | 'queued'
  | 'running'
  | 'completed'
  | 'failed';

export interface RouteRequest {
  origin: string;
  destination: string;
  date_from: string;
  date_to: string;
  citizenship?: string;
  passengers?: number;
  currency?: string;
  budget?: number | string | null;
  limit?: number;
  excluded_cities?: string[];
  checked_baggage_required?: boolean;
}

export interface CreateQueryResponse {
  query_id: string;
}

export interface QueryStatusResponse {
  query_id: string;
  status: QueryStatus;
}

export interface FlightSearchResult {
  offers: TicketOffer[];
  complete: boolean;
  warnings: string[];
}

export interface QueryResult extends FlightSearchResult {
  query_id: string;
}

// Вложенные типы результата добавляются по мере необходимости.
export interface TicketOffer {
  provider: string;
  offer_id: string;
  total_price: {
    amount: string;
    currency: string;
  };
  passengers: number;
  cabin: 'economy' | 'premium_economy' | 'business' | 'first';
  checked_baggage_included: boolean | null;
  protected_connection: boolean;
  booking_url: string | null;
  fetched_at: string;
  expires_at: string;
  segments: FlightSegment[];
}

export interface FlightSegment {
  origin: Airport;
  destination: Airport;
  departure_at: string;
  arrival_at: string;
  marketing_carrier: string;
  operating_carrier: string;
  flight_number: string;
}

export interface Airport {
  code: string;
  city_code: string;
  timezone: string;
}

export async function createRoute(
  request: RouteRequest,
): Promise<CreateQueryResponse> {
  const { data } = await api.post<CreateQueryResponse>(
    '/queries',
    request,
  );

  return data;
}

export async function getRouteStatus(
  queryId: string,
): Promise<QueryStatusResponse> {
  const { data } = await api.get<QueryStatusResponse>(
    `/queries/${encodeURIComponent(queryId)}`,
  );

  return data;
}

export async function getRouteResult(
  queryId: string,
): Promise<QueryResult> {
  const { data } = await api.get<QueryResult>(
    `/queries/${encodeURIComponent(queryId)}/result`,
  );

  return data;
}